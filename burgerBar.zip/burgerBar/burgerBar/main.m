//
//  main.m
//  burgerBar
//
//  Created by Matthew Sinclair on 10/10/16.
//  Copyright © 2016 Matthew Sinclair. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
       
        //the # of burgers
        //the #of shakes
        //the number of customers
        //if the order was for take-out or not
        // the order subtotal
        
        NSDictionary *orderDict = @{
                                    @"burgers": @5,
                                    @"shakes": @3,
                                    @"customers": @4,
                                    @"isTakeOut": @NO,
                                    @"subtotal": @0.0,
                                    };
        
        float burgerPrice = 4;
        float shakePrice = 3;
        float subtotal;
        
        subtotal = (burgerPrice *[[orderDict valueForKey:@"burgers"] intValue]) + (shakePrice* [[orderDict valueForKey:@"shakes"]intValue]);
        
        NSMutableDictionary *outputDict = [NSMutableDictionary dictionaryWithDictionary:orderDict];
        
        [outputDict setValue:@(subtotal) forKey:@"subtotal"];
        

        NSMutableDictionary *testDict = [[NSMutableDictionary alloc] initWithObjectsAndKeys:@5, @"burgers", @3, @"shakes", nil];

    }
    return 0;
}
