//
//  main.m
//  Array manipulation quiz
//
//  Created by Matthew Sinclair on 10/12/16.
//  Copyright © 2016 Matthew Sinclair. All rights reserved.
//

#import <Foundation/Foundation.h>

//This code shows how to pull strings and other objects out of an array

int main(int argc, const char * argv[]) {
  
    NSArray *drinks = [[NSArray alloc] initWithObjects: @"juice", @"water", @"coffee", nil];
    
    for (NSString *grabDrink in drinks) {
        NSLog(@"The drink in hand is: %@", grabDrink);
    }
    return 0;
}
