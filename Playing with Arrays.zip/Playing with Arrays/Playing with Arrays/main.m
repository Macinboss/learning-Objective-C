//
//  main.m
//  Playing with Arrays
//
//  Created by Matthew Sinclair on 10/12/16.
//  Copyright © 2016 Matthew Sinclair. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
   
    
    //Array elements MUST be Objects - not primitives (int, float, double, etc.)
    //To use them, you need to wrap them into an NSInt or NSFloat
    
    NSArray *myArray = @[@"This", @"is", @"my", @"Array"];
    
    //This creates an NSArray using alloc/init
    NSArray *nameArray = [[NSArray alloc] initWithObjects:
                          @"Andrew", @"Steve", @"Matthew", @"Tim", nil];
    
    NSMutableArray *myMutableArray = [NSMutableArray arrayWithObjects: @"Andrew", @"Kenneth", @"Craig",@"Kenneth", nil];
    
   /*running  [myMutableArray replaceObjectAtIndex:2 withObject:@"Stan"]; would change arrayIndex to Stan (as it replaces Craig before arrayIndex is created, which would then be printed when running NSLog */
    
    NSString *arrayIndex = [myMutableArray objectAtIndex:2];
    
    /* running [myMutableArray replaceObjectAtIndex:2 withObject:@"Stan"]; here would print Craig, as it was saved to the arrayIndex prior to it's change. This stores the value for Craig in arrayIndex so it's not lost, but still not a element of the array */
    
    [myMutableArray removeObjectAtIndex:0];
    int countMyMutableArray = [myMutableArray count];
    
    //to insert an additional element into the 3rd spot, and bump all other elements up one index
     [myMutableArray insertObject:@"newObject" atIndex:2];
    
    //to add something to an array TO THE END OF THE ARRAY use
    [myMutableArray addObject:@"Zedd"];
    
    NSLog(@"This is my friend %i %@", countMyMutableArray, arrayIndex);
    
    return 0;
}
