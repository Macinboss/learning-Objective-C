//
//  main.m
//  mattsKFC
//
//  Created by Matthew Sinclair on 10/14/16.
//  Copyright © 2016 Matthew Sinclair. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
   
    //Chicken Bucket - price $10.00, cost 3.75
    //Chicken Sandwich - price $3.25, cost $1.25
    //Soda - price $2.00, cost $0.25
    
    //Family Deal - 1 Bucket, 4 Sodas - price $15.00, cost $4.75
    //Double Trouble - 2 sandwitches, 2 sodas - price $9.50, Cost 4.50
    //Lonely Bird - 1 sandwich, 1 soda - price $5.00, cost $1.50
    
    //East side profit $710 last month
    
    //The sales data will be one large list, 200+ items.
    
    //The total amout of operating profit
    float revenueTotal = 0;
    
    // The total amout of cost it took to run the buisness
    float costTotal = 0;
    
    float profitTotal = 0;
    
    float chickenBucketPrice = 10.00;
    float chickenSandwichPrice = 3.25;
    float sodaPrice = 2.00;
    float familyDealPrice = 15.00;
    float doubleTroublePrice = 9.50;
    float lonelyBirdPrice = 5.00;
    
    
    float chickenBucketCost = 3.75;
    float chickenSandwichCost = 1.25;
    float sodaCost = 0.25;
    float familyDealCost = 4.75;
    float doubleTroubleCost = 4.50;;
    float lonelyBirdCost = 1.50;
    
    typedef enum orderItem{
        Bucket = 1,
        Sandwich = 2,
        Soda = 3,
        FamilyDeal = 4,
        DoubleTrouble = 5,
        LonelyBird = 6
    }orderItem;
    
    //Full Array
    NSArray *orderArray = @[ @(Soda), @(Sandwich), @(Sandwich), @(Bucket), @(FamilyDeal), @(Sandwich), @(DoubleTrouble), @(LonelyBird), @(DoubleTrouble), @(Soda),@(Soda), @(Sandwich), @(Sandwich), @(Bucket), @(FamilyDeal), @(Sandwich), @(DoubleTrouble), @(LonelyBird), @(DoubleTrouble), @(Soda),@(Soda), @(Sandwich), @(Sandwich), @(Bucket), @(FamilyDeal), @(Sandwich), @(DoubleTrouble), @(LonelyBird), @(DoubleTrouble), @(Soda),@(Soda), @(Sandwich), @(Sandwich), @(Bucket), @(FamilyDeal), @(Sandwich), @(DoubleTrouble), @(LonelyBird), @(DoubleTrouble), @(Soda),@(Soda), @(Sandwich), @(Sandwich), @(Bucket), @(FamilyDeal), @(Sandwich), @(DoubleTrouble), @(LonelyBird), @(DoubleTrouble), @(Soda),@(Soda), @(Sandwich), @(Sandwich), @(Bucket), @(FamilyDeal), @(Sandwich), @(DoubleTrouble), @(LonelyBird), @(DoubleTrouble), @(Soda),@(Soda), @(Sandwich), @(Sandwich), @(Bucket), @(FamilyDeal), @(Sandwich), @(DoubleTrouble), @(LonelyBird), @(DoubleTrouble), @(Soda),@(Soda), @(Sandwich), @(Sandwich), @(Bucket), @(FamilyDeal), @(Sandwich), @(DoubleTrouble), @(LonelyBird), @(DoubleTrouble), @(Soda),@(Soda), @(Sandwich), @(Sandwich), @(Bucket), @(FamilyDeal), @(Sandwich), @(DoubleTrouble), @(LonelyBird), @(DoubleTrouble), @(Soda),@(Soda), @(Sandwich), @(Sandwich), @(Bucket), @(FamilyDeal), @(Sandwich), @(DoubleTrouble), @(LonelyBird), @(DoubleTrouble), @(Soda),@(Soda), @(Sandwich), @(Sandwich), @(Bucket), @(FamilyDeal), @(Sandwich), @(DoubleTrouble), @(LonelyBird), @(DoubleTrouble), @(Soda),@(Soda), @(Sandwich), @(Sandwich), @(Bucket), @(FamilyDeal), @(Sandwich), @(DoubleTrouble), @(LonelyBird), @(DoubleTrouble), @(Soda),@(Soda), @(Sandwich), @(Sandwich), @(Bucket), @(FamilyDeal), @(Sandwich), @(DoubleTrouble), @(LonelyBird), @(DoubleTrouble), @(Soda),@(Soda), @(Sandwich), @(Sandwich), @(Bucket), @(FamilyDeal), @(Sandwich), @(DoubleTrouble), @(LonelyBird), @(DoubleTrouble), @(Soda),@(Soda), @(Sandwich), @(Sandwich), @(Bucket), @(FamilyDeal), @(Sandwich), @(DoubleTrouble), @(LonelyBird), @(DoubleTrouble), @(Soda),@(Soda), @(Sandwich), @(Sandwich), @(Bucket), @(FamilyDeal), @(Sandwich), @(DoubleTrouble), @(LonelyBird), @(DoubleTrouble), @(Soda),@(Soda), @(Sandwich), @(Sandwich), @(Bucket), @(FamilyDeal), @(Sandwich), @(DoubleTrouble), @(LonelyBird), @(DoubleTrouble), @(Soda),@(Soda), @(Sandwich), @(Sandwich), @(Bucket), @(FamilyDeal), @(Sandwich), @(DoubleTrouble), @(LonelyBird), @(DoubleTrouble), @(Soda),@(Soda), @(Sandwich), @(Sandwich), @(Bucket), @(FamilyDeal), @(Sandwich), @(DoubleTrouble), @(LonelyBird), @(DoubleTrouble), @(Soda),@(Soda), @(Sandwich), @(Sandwich), @(Bucket), @(FamilyDeal), @(Sandwich), @(DoubleTrouble), @(LonelyBird), @(DoubleTrouble), @(Soda)];

    
    for (NSNumber *orderItem in orderArray){
        switch ([orderItem integerValue]) {
            case Bucket:
                
                revenueTotal = revenueTotal + chickenBucketPrice;
                costTotal = costTotal + chickenBucketCost;
                
                break;
            
            case Sandwich:
                revenueTotal = revenueTotal + chickenSandwichPrice;
                costTotal = costTotal + chickenSandwichCost;
                break;
            
            case Soda:
                revenueTotal = revenueTotal + sodaPrice;
                costTotal = costTotal + sodaCost;
                break;
            
            case FamilyDeal:
                revenueTotal = revenueTotal + familyDealPrice;
                costTotal = costTotal + familyDealCost;
                break;
            
            case DoubleTrouble:
                revenueTotal = revenueTotal + doubleTroublePrice;
                costTotal = costTotal + doubleTroubleCost;
                break;
                
            case LonelyBird:
                revenueTotal = revenueTotal + lonelyBirdPrice;
                costTotal = costTotal + lonelyBirdCost;
                break;
                
            default: NSLog(@"This is not a menu item.");
                break;
        }
    }
    
    profitTotal = profitTotal + (revenueTotal - costTotal);
     
    NSLog(@"Our total operiting revenue was a total of %f, with a profit of %f, and a total operating expendatire of %f", revenueTotal, profitTotal, costTotal);
    
    return 0;
}
