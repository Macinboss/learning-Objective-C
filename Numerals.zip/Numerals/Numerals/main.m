//
//  main.m
//  Numerals
//
//  Created by Matthew Sinclair on 10/8/16.
//  Copyright © 2016 Matthew Sinclair. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
    }
    
    int currentAge;
    
    currentAge = 24;
    
    float currentWeight;
    currentWeight = 155.6;
    
    float currentHeight;
    currentHeight = 66.0;
    
    double currentWeightPerInch;
    
    currentWeightPerInch = currentWeight/currentHeight;
    
    //%f Prints the token of the float
    //%i Prints the token of the int
    
    NSLog(@"currentHeight is: %f", currentHeight);
    NSLog(@"currentWeight is: %f", currentWeight);
    NSLog(@"currentWeightPerInch is: %f", currentWeightPerInch);
    
    //%f is the token for a float AND a double
    
    return 0;
}
