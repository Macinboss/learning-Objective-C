//
//  TableCheck.h
//  DalesDiner
//
//  Created by Matthew Sinclair on 10/15/16.
//  Copyright © 2016 Matthew Sinclair. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TableCheck : NSObject

@property (nonatomic) int serverNumber;
@property (nonatomic) float subtotal;
@property (nonatomic) float tip;
@property (nonatomic) float total;
@property (nonatomic, strong) NSMutableArray *itemsOrdered;
@property (nonatomic) bool isTakeOut;

/*
int serverNumber; // which server handles the table
int tableNumber; //physical table location
float subtotal;
float tip;
bool isTakeOut;
NSMutableArray *itemOrdered;
NSDate *timeStamp;

*/
@end
