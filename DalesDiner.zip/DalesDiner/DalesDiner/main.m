//
//  main.m
//  DalesDiner
//
//  Created by Matthew Sinclair on 10/15/16.
//  Copyright © 2016 Matthew Sinclair. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TableCheck.h"

int main(int argc, const char * argv[]) {
    
    TableCheck *tableOne = [[TableCheck alloc] init];
    
    tableOne.subtotal = 15;
    tableOne.tip = 5;
    tableOne.isTakeOut = YES;
    
    
    //Setting savedTip to get
    float savedTip = tableOne.tip;
    
    return 0;
}
