//
//  TableCheck.m
//  DalesDiner
//
//  Created by Matthew Sinclair on 10/15/16.
//  Copyright © 2016 Matthew Sinclair. All rights reserved.
//

#import "TableCheck.h"

@implementation TableCheck

@end
