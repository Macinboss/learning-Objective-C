//
//  main.m
//  history class
//
//  Created by Matthew Sinclair on 10/12/16.
//  Copyright © 2016 Matthew Sinclair. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    
    // Quiz Scores: 100, 85, 80, 76, 72
    
    NSArray *quizScores = @[@100, @85, @80, @76, @72];

    float score = 0;
    
    for (NSNumber *quizScore in quizScores) {
        score = score + [quizScore intValue];
        
    }
    float classAverage = score / [quizScores count];
    
    NSLog(@" The class average is %f", classAverage);
    
    NSMutableArray *seatingArray = [NSMutableArray arrayWithObjects: @"Page", @"Chris", @"Ernest", @"Mike", @"John", nil];
    
    //This code removes Mike from the class
    [seatingArray removeObjectAtIndex:3];
    
    // [seatingArray removeObjectIdenticalTo:@"Mike"]; can also be used if you don't know what might be in the array.
    
    //this code ads Phil to the class, and places him in mike's seat
    [seatingArray insertObject:@"Phil" atIndex:1];

    
    return 0;
}
