//
//  main.m
//  Math Ops
//
//  Created by Matthew Sinclair on 10/9/16.
//  Copyright © 2016 Matthew Sinclair. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
    }

    int apples = 3 + 5;
    
    int oranges = 10 - 3 - 5;
    
    int totalFruit = apples + oranges;
    
    int eggsPerCarton = 12;
    
    int eggs = eggsPerCarton * 4;
    
    int baskets = 4;
    
    float itemsPerBasket = ((apples + oranges + eggs) / baskets);
    
    return itemsPerBasket;
    
    
    return 0;
}
