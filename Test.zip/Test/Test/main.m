//
//  main.m
//  Test
//
//  Created by Matthew Sinclair on 10/10/16.
//  Copyright © 2016 Matthew Sinclair. @"All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
  
    
    int mathTotal;
    bool isComplete;
    int goalMathTotal = 25;
    
    for(int i = 5; i < 26; i++){
        
        mathTotal = i;
        
        if(mathTotal == goalMathTotal){
            isComplete = true;
            NSLog(@"The problem is complete.");
        }
        else{
            
            isComplete = false;
        }
    }
    
    NSLog(@"%i", mathTotal);
    return 0;
}
