//
//  main.m
//  PingPong (arc4random)
//
//  Created by Matthew Sinclair on 10/20/16.
//  Copyright © 2016 Matthew Sinclair. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    
int playerOneScore = 0;
int playerTwoScore = 0;
    int winningScore = 21;
    
    do{
        int point = arc4random()%2;
        if(point == 0){
            playerOneScore++;
            NSLog(@"Player one score = %i, Player two score = %i", playerOneScore, playerTwoScore);
        }else {
            playerTwoScore++;
            NSLog(@"Player one score = %i, Player two score = %i", playerOneScore, playerTwoScore);
        }
        
    }
    while(!(playerOneScore > playerTwoScore+2 && playerOneScore >= winningScore) || ((playerTwoScore > playerOneScore+2) && (playerTwoScore >= winningScore)));

    if(playerOneScore > playerTwoScore+2){
        NSLog(@"Player one wins! %i to %i", playerOneScore, playerTwoScore);
    }else if(playerTwoScore > playerOneScore){
        NSLog(@"Player two wins! %i to %i", playerTwoScore, playerOneScore);
    }else{
        NSLog(@"The game has ended in a draw");
    }
    
          return 0;
}
