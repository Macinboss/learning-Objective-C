//
//  main.m
//  99Bottles of Beer on the wall
//
//  Created by Matthew Sinclair on 10/10/16.
//  Copyright © 2016 Matthew Sinclair. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
  
    for (int i = 99; i > 0; i--){
        NSLog(@" %i bottles of beer on the wall, \n %i bottles of beer, \n take one down, pass it around, \n %i bottles of beer on the wall.", i,i, (i-1));
              }
    
    int mathTotal;
    bool isComplete;
    
    for(i = 5; i < 26; i++){
        mathTotal = mathTotal + i;
    }
    
    isComplete = true;
    
    
    return 0;
}
