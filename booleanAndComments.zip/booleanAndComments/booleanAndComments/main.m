//
//  main.m
//  booleanAndComments
//
//  Created by Matthew Sinclair on 10/8/16.
//  Copyright © 2016 Matthew Sinclair. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
    }
    
  
    bool hasLicense;
//This bool refers to people who has a valid US drivers license
    
    hasLicense = false;
    
    NSLog(@"Has license: %i", hasLicense);
    
    if (hasLicense == false) {
        NSLog(@"The driver does not have a valid US license");
    }
    else{ NSLog(@"The driver has a valid US license");
    return 0;
    }
}
