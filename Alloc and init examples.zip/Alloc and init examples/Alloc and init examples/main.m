//
//  main.m
//  Alloc and init examples
//
//  Created by Matthew Sinclair on 10/11/16.
//  Copyright © 2016 Matthew Sinclair. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    
    NSMutableDictionary *carDict = [[NSMutableDictionary alloc] initWithObjectsAndKeys: @"Honda",@"Make",@"Accord",@"Model", nil];
    NSString *myRide = [[NSString alloc] init];

    myRide = [carDict valueForKey:@"Make"];

    NSLog(@"My car manufacturer is %@", myRide);

    return 0;
}
