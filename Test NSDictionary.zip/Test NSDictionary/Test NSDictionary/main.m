//
//  main.m
//  Test NSDictionary
//
//  Created by Matthew Sinclair on 10/11/16.
//  Copyright © 2016 Matthew Sinclair. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
/*
    NSDictionary *artDict = @{
                              @"Artist": @"Dali",
                              @"Title": @"The Ship",
                              @"Medium": @"Oil Paint",
                              };
    
    NSMutableDictionary *mutArtDict = [NSMutableDictionary dictionaryWithDictionary:artDict];
    
    NSString *favoriteArtist = [mutArtDict valueForKey:@"Artist"];
    
    NSLog(@"My favorite artist is %@", favoriteArtist);
*/
   // NSMutableDictionary *carDict = [[NSMutableDictionary alloc] initWithObjectsAndKeys: @"Make",@"Honda", @"Model", @"Accord", nil];
    
NSMutableDictionary *carDict = [[NSMutableDictionary alloc] initWithObjectsAndKeys:@"Honda", @"Make", @"Accord",@"Model", nil];
    
    for(NSString *key in [carDict allKeys]) {
        NSLog(@"%@",[carDict objectForKey:key]);
    }
    
    return 0;
}
