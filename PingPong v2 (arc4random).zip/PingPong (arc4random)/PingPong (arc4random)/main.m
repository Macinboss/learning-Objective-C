//
//  main.m
//  PingPong (arc4random)
//
//  Created by Matthew Sinclair on 10/20/16.
//  Copyright © 2016 Matthew Sinclair. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    
int playerOneScore = 0;
int playerTwoScore = 0;
int winningScore = 21;

    bool gameOn = true;
    
    while(gameOn == true){
        int point = arc4random()%2;
        
        if(point == 0){
            playerOneScore++;
        }
        else if(point == 1){
            playerTwoScore++;
        }
        
        if((winningScore <= playerOneScore) && (playerOneScore > playerOneScore - playerTwoScore+2)){
            gameOn = false;
            NSLog(@"Player one wins! %i to %i", playerOneScore, playerTwoScore);
        }
        if((winningScore <= playerTwoScore) && (playerTwoScore > playerTwoScore - playerOneScore+2)){
            gameOn = false;
            NSLog(@"Player one wins! %i to %i", playerOneScore, playerTwoScore);
        }

        
    }//Below is flawed logic I was testing with
    
       /* if(winningScore == playerOneScore - playerTwoScore+2){
            gameOn = false;
            NSLog(@"Player one wins! %i to %i", playerOneScore, playerTwoScore);}else{
                NSLog(@"Player one score = %i, Player two score = %i", playerOneScore, playerTwoScore);}}

    
        if(winningScore == playerTwoScore - playerOneScore+2){
                gameOn = false;
                NSLog(@"Player two wins! %i to %i", playerTwoScore, playerOneScore);}else{
                    NSLog(@"Player one score = %i, Player two score = %i", playerOneScore, playerTwoScore);}
            //NSLog(@"The game has ended in a draw");

        (!(playerOneScore > playerTwoScore+2 && playerOneScore >= winningScore) || ((playerTwoScore > playerOneScore+2) && (playerTwoScore >= winningScore)));
*/
    
          return 0;
}
