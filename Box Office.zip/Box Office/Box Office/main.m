//
//  main.m
//  Box Office
//
//  Created by Matthew Sinclair on 10/9/16.
//  Copyright © 2016 Matthew Sinclair. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
    }
    
    
    //Regular price = $10
    //Customers over 65 = $5
    
    //adding matinee required reworking of logic. Deprocated logic is in notes below.
    
    bool isMatinee = YES;
    
    float matineePrice = 4;
    float regPrice = 10;
    float seniorPrice = 5;
    
    int minAge = 60;
    
    int custAge = 62;
    float custPrice;
    
    /*
    if(custAge >= minAge){
        custPrice = seniorPrice;
    }
    
    else{
        custPrice = regPrice;
        
    }
    
    return custPrice;
    
     */
    
    //Commenting out ticket price code for Switch Code.
    
    /*
    if(isMatinee){
        custPrice = matineePrice;
    }
    
    else if(custAge >= minAge){
        custPrice = seniorPrice;
    }
    
    else{
        custPrice = regPrice;
        
    }
    
    return custPrice;
    
    */
    
    //Popcorn sizes and prices
    //Kids - $1.50
    //Small - $3.00
    //Medium - $4.25
    //Large - $5.25
    //Tub - $6.00
    
    float popcornPrice;
    int popcornSize = 3;
    
    switch (popcornSize) {
        case 1:
            popcornPrice = 1.5;
            break;
        case 2:
            popcornPrice = 3.0;
            break;
        case 3:
            popcornPrice = 4.25;
            break;
        case 4:
            popcornPrice = 5.25;
            break;
        case 5:
            popcornPrice = 6.;
            break;
            
        default:
            NSLog(@"No valid size entered");
            
            return popcornPrice;
            break;
    }
    
    
    return 0;
}
