//
//  main.m
//  loopy
//
//  Created by Matthew Sinclair on 10/10/16.
//  Copyright © 2016 Matthew Sinclair. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    
    //For Loop
    
    /*
    int runningTotal = 0;
    
    for (int i = 1; i <= 50; i++){
        
        runningTotal = runningTotal + i;
        NSLog(@"i = %i", i);
    }
    
    */
    
    
    
    
    
    return 0;
}
