//
//  main.m
//  BoxOffice+
//
//  Created by Matthew Sinclair on 10/10/16.
//  Copyright © 2016 Matthew Sinclair. All rights reserved.
//

#import <Foundation/Foundation.h>

NSString *empMessage;

void printTicket(){
    empMessage = @"Printed message";
    NSLog(@"%@", empMessage);
}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
    }
    
    
    // AND &&
    // OR ||
    //NOT !
    
    //Is the customer under the age of 13 or over the age of 65? if so they get ageDiscount
    //is the movie a matinee?(First showing of the day) if so, customer gets isMatinee price
    //Is the customer a theatre employee? if so they get the isEmployee price.
    
    bool ageDiscount;
    bool isMatinee = YES;
    bool isEmployee;
    
    //Full price ticket is = $10
    // non-employee with an age discount OR is seeing a mattinee = $8
    //non-employee with an age discount AND is seeing a mattinee = $6.50
    // employee attending a non-mattinee = $4.50
    // employee attending a mattinee = free
    
    
    float regPrice = 10;
    float ageOrMatineePrice = 8.5;
    float ageAndMatineePrice = 6.5;
    float employeeNotMatinee = 4.5;
    float employeeAndMatinee = 0;
    
    float customerPrice;
    int customerAge;
    
    int youthAge = 13;
    int seniorAge = 65;
    
    float subtotal = 0;
    float taxRate = 0.05;
    float grandTotal = 0;
    
    NSArray *agesArray = @[@5, @5, @14, @42, @77];
    
    /*this loop says: We're going to take an NSNumber (created with the @ infront of the number) from the agesArray, convert it to its integer value and call it age. Then it will set customerAge to the new int value called age, and pass it through the loop to calculate the ticket price
    */
    for (NSNumber *age in agesArray) {
    
        customerAge = [age intValue];
        
    //assess age discount
    ageDiscount = ((customerAge < youthAge) || (customerAge >= seniorAge)) ? YES:NO;
    
    //determinePrice
    if (ageDiscount && isMatinee && !isEmployee){
        customerPrice = ageAndMatineePrice;
    }
    
    else if ((ageDiscount || isMatinee) && !isEmployee){
        customerPrice = ageOrMatineePrice;
    }
    else if (isEmployee && !isMatinee){
        customerPrice = employeeNotMatinee;
        empMessage = @"Thanks for being part of the team. Enjoy your movie!";
        NSLog(@"%@", empMessage);
    }
    else if (isEmployee && isMatinee){
        customerPrice = employeeAndMatinee;
        empMessage = @"Thanks for being part of the team. Enjoy your free movie!";
        NSLog(@"%@", empMessage);
    }
    
    else{
        customerPrice = regPrice;
    }
        subtotal = subtotal + customerPrice;
       
        
        NSLog(@"age: %i customer price: %f current subtotal: %f /n", customerAge, customerPrice, subtotal);
       
    }
     grandTotal = subtotal + (subtotal * taxRate);
     NSLog(@"Grand total is: %f", grandTotal);
    
    printTicket();
    return 0;
}
